<?php
	include dirname(__FILE__) . '/config.php';
	include TEMPLATE . '/404.html';
?>
